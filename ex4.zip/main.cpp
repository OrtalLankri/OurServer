
#include "Main.h"

using namespace boot;

int main(int argc, char *argv[])
{
    Main main1;
    main1.main(argc,argv);
}